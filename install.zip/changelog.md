### v1.0.0 - 26 Sep 2024
* Initial release