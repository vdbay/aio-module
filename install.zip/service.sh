#!/system/bin/sh
VCCSH=$MODPATH/cc.sh
